var http = require("http");
var url = require("url");
var _mysql = require('mysql');
var port = 8181;
http.createServer(function(request, response) {
	var pathname = url.parse(request.url).pathname;
	//创建连接
	var mysql = _mysql.createConnection({

		//主机
		host: '27017',
		//用户
		user: '001', //
		//密码
		password: '123456', //数据库密码
		//端口
		port: 3306,
		//数据库名
		database: 'BookStore' //数据库名称
	});
	console.log("当前位置:location=" + pathname);
	response.writeHead(200, {
		"Content-Type": 'application/json',
		'charset': 'utf-8',
		'Access-Control-Allow-Origin': '*',
		'Access-Control-Allow-Methods': 'PUT,POST,GET,DELETE,OPTIONS'
	}); //可以解决跨域的请求

	var jsonobj;
	var postdata = ""; //存储http请求中携带的数据
	request.on('data', function(chunk) {
		// chunk 默认是一个二进制数据，和 data 拼接会自动 toString
		postdata += chunk;
	});
	switch(pathname) {
		case "/":
			mysql.query("select * from  w_user", function(err, rows) {
				if(err) {
					console.log("query-" + err);
					response.write("发生错误");
					response.end();
					return;
				}
				if(rows.length < 1) {
					response.write("-1");
					response.end();
					return;
				}
				var namelist = [];
				var users = {
					code: 0,
					message: "查询成功",
					data: namelist
				};
				for(var i = 0; i < rows.length; i++) {
					var allname = {
						id: rows[i].id,
						name: rows[i].name,
						sex: rows[i].sex,
						age: rows[i].age,
						money: rows[i].money,
						position: rows[i].position,
						idcard: rows[i].idcard
					}
					namelist.push(allname);
				}
				var resobj = JSON.stringify(users)
				console.log("query succeed..." + rows.length);
				response.write(resobj);
				response.end();
			});
			break;
		case "/query":
			request.on('end', function() {
				postdata = decodeURI(postdata);
				jsonobj = JSON.parse(postdata);
				var id;
				id = jsonobj.id;
				console.log("数据" + jsonobj.name);
				var sql = "select * from  w_user where id=?"
				var params = [id];
				//查询
				mysql.query(sql, params, function(err, rows) {
					if(err) {
						console.log("query-" + err);
						response.write(err);
						response.end();
						return;
					}
					if(rows.length < 1) {
						response.write("-1");
						response.end();
						return;
					}
					var namefid = {
						id: rows[0].id,
						name: rows[0].name,
						sex: rows[0].sex,
						age: rows[0].age,
						money: rows[0].money,
						position: rows[0].position,
						idcard: rows[0].idcard
					}
					var resobj = JSON.stringify(namefid)
					console.log("query succeed..." + rows.length);
					response.write(resobj);
					response.end();
				});
			});
			break;
		case "/insert":
			request.on('end', function() {
				postdata = decodeURI(postdata);
				jsonobj = JSON.parse(postdata);
				console.log("数据" + postdata);
				var sql = "insert into  w_user(name,sex,age,money,position,idcard) value(?,?,?,?,?,?)"
				var Params = [jsonobj.name, jsonobj.sex, jsonobj.age, jsonobj.money,jsonobj.position,jsonobj.idcard];
				//增 add
				mysql.query(sql, Params, function(err, result) {
					if(err) {
						response.write('[INSERT ERROR] - ' + JSON.stringify(err));
						response.end();
						return;
					}
					console.log("成功")
					var res = {
						result: 1,
						msg: jsonobj.name + "插入成功"
					}
					response.write(JSON.stringify(res));
					response.end();
				});
			});
			break;
		case "/update":
			request.on('end', function() {
				postdata = decodeURI(postdata);
				jsonobj = JSON.parse(postdata);
				console.log("数据更新" + jsonobj.name);
				var sql = 'UPDATE w_user SET name=?,sex=?,age=?,money=?,position=?,idcard=? where id=?';
				var Params = [jsonobj.name, jsonobj.sex, jsonobj.age, jsonobj.money,jsonobj.position,jsonobj.idcard,jsonobj.id];
				console.log(JSON.stringify(Params))
				//增 add
				mysql.query(sql, Params, function(err, result) {
					console.log("修改")
					if(err) {
						console.log('[UPDATE ERROR] - ' + err.message)
						response.write('[UPDATE ERROR] - ' + err.message);
						response.end();
						return;
					}
					var res = {
						result: result.changedRows
					};
					if(result.changedRows < 1) {
						res.msg = jsonobj.name + ":未更新"
					} else {
						res.msg = jsonobj.name + ":更新成功"
					}
					response.write(JSON.stringify(res));
					response.end();
				});
			});
			break;
		case "/delete":
			request.on('end', function() {
				postdata = decodeURI(postdata);
				jsonobj = JSON.parse(postdata);
				var sql = 'delete from w_user where id = ?';
				var Params = [jsonobj.id];
				//增 add
				mysql.query(sql, Params, function(err, result) {
					if(err != null) {
						response.write('[DELETE ERROR] - ' + err.message);
						response.end();
						return;
					}
					console.log("删除" + JSON.stringify(result))
					var res = {
						result: 1,
						msg: jsonobj.name + "删除成功"
					}
					response.write(JSON.stringify(res));
					response.end();
				});
			});
			break;
		default:
			response.write("接口地址不正确");
			response.end();
			break;
	}

}).listen(port);
console.log("开启服务，localhost:" + port);