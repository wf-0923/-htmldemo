var url = "localhost:8181";
//初始化数据
var dataCsh = "{\"msg\": \"select\"}";
$.post("http://" + url + "/", dataCsh, function(data) {
	console.log(JSON.stringify(data))
	var dataJson = JSON.stringify(data);
	//  var obj = jQuery.parseJSON(dataJson);
	var obj = data.data;
	var tableHtml = "";
	var j = 1;
	for(var i in obj) {
		tableHtml += "<tr>";
		tableHtml += "<td>" + obj[i].id + "</td>";
		tableHtml += "<td>" + obj[i].name + "</td>";
		tableHtml += "<td>" + obj[i].age + "</td>";
		tableHtml += "<td>" + obj[i].sex + "</td>";
		tableHtml += '<td>' + obj[i].money + '</td>';
		tableHtml += "<td>" + obj[i].idcard + "</td>";
		tableHtml += "<td>" + obj[i].position + "</td>";
		tableHtml += "<td><button type=\"button\" onclick=\"fun_del('" + obj[i].id + "')\" class=\"btn btn-danger btn-xs btn_del\">删除</button>&nbsp;&nbsp;&nbsp;" +
			"<button type=\"button\" onclick=\"fun_update('" + obj[i].id + "')\" class=\"btn btn-xs btn-primary\" >编辑</button></td>";
		tableHtml += "</tr>";
	}
	$("#aj_data").html(tableHtml);
}, "json");

function fun_del(id) {
	var deleteData = "{\"id\":\"" + id + "\"}";
	console.log("你点击了第  '" + deleteData + "'  项")
	//	alert("你点击了第  '" + deleteData + "'  项");
	$.post("http://" + url + "/delete", deleteData, function(data) {
		var dataJson = JSON.stringify(data);
		var obj = jQuery.parseJSON(dataJson);
		if(obj.isOk = "true") {
			alert("删除成功");
			window.location.reload();
		}
	});
}

var selectData = "";

function fun_update(id) {
	localStorage.setItem("test",id)
	selectData = id;
	layer.open({
		type: 2,
		title: false //不显示标题栏
			,
		closeBtn: true,
		offset: 'auto',
		area: ['400px', '550px'],
		shade: 0.5,
		id: 'verification' //设定一个id，防止重复弹出
			,
		resize: false,
		moveType: 1 //拖拽模式，0或者1
			,
		content: ['upDataModal.html', 'no'],
		anim: 0,
		scrollbar: false,
		end: function() {
			window.location.reload();
		}
	});
}

function chuancan() {
	return selectData;
}